package com.example.ayedg1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.LoginFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private  int counter = 3;
private TextView info = (TextView)findViewById(R.id.button2);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
           final EditText user = (EditText) findViewById(R.id.userName);
           final EditText pass = (EditText) findViewById(R.id.password);
            final TextView AA = (TextView) findViewById(R.id.textView4);
        Button btn = (Button) findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(user.getText().toString(), pass.getText().toString());
            }
        });
}
private void validate(String userName,String password){
        if (userName.equals("ayed")&&
        (password.equals("123"))) {
            Intent i = new Intent(getApplicationContext(), Main2Activity.class);
            startActivity(i);
        } else {
            counter--;
            info.setText("text"+String.valueOf(counter));
        }
        }
        }